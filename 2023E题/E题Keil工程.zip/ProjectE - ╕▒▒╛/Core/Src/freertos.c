/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "system_control.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern int16_t squareCoordinates[4][2];

TaskHandle_t task_LedHandle;
TaskHandle_t task_KeyPressHandle;
TaskHandle_t task_FollowLineHandle;

/* USER CODE END Variables */
osThreadId defaultTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

void Task_Led(void const * argument);
void Task_KeyPressed(void const * argument);
void Task_FollowLine(void const * argument);

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  taskENTER_CRITICAL();

  //max prio 7
  xTaskCreate((TaskFunction_t)Task_Led,"Led",
              configMINIMAL_STACK_SIZE,NULL,1,&task_LedHandle);

  xTaskCreate((TaskFunction_t)Task_KeyPressed,"KeyPressed",
              configMINIMAL_STACK_SIZE,NULL,2,&task_KeyPressHandle);

  xTaskCreate((TaskFunction_t)Task_FollowLine,"FollowLine",
              configMINIMAL_STACK_SIZE*4,NULL,3,&task_FollowLineHandle);

  vTaskDelete(defaultTaskHandle);

  taskEXIT_CRITICAL();
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

//led闪烁任务，用于检查程序是否正常运行
void Task_Led(void const * argument){
  while (1)
  {
    vTaskDelay(1000);
    HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
  }
}

//按键检测任务，用状态机实现按键检测，消抖
void Task_KeyPressed(void const * argument){
  uint8_t currentStatus=0;
  GPIO_TypeDef * checkingPort=NULL;
  uint16_t checkingPin=0;

  while (1)
  {
    switch (currentStatus)
    {
    case 0://check pressed
      vTaskDelay(10);
      if(HAL_GPIO_ReadPin(Reset_GPIO_Port,Reset_Pin)==GPIO_PIN_RESET){
        checkingPort=Reset_GPIO_Port;
        checkingPin=Reset_Pin;
        currentStatus=1;
      }else if(HAL_GPIO_ReadPin(Follow_GPIO_Port,Follow_Pin)==GPIO_PIN_RESET){
        checkingPort=Follow_GPIO_Port;
        checkingPin=Follow_Pin;
        currentStatus=1;
      }
      break;
    
    case 1://avoid vibrate
      vTaskDelay(10);
      if(HAL_GPIO_ReadPin(checkingPort,checkingPin)==GPIO_PIN_RESET){
        currentStatus=2;
      }else{
        currentStatus=0;
      }
      break;
    case 2://check resume
      vTaskDelay(10);
      if(HAL_GPIO_ReadPin(checkingPort,checkingPin)==GPIO_PIN_SET){
        currentStatus=0;

        //make movement
        if(checkingPin==Reset_Pin){
          System_Init();

        }
        if(checkingPin==Follow_Pin){
          //System_setToCoordinate(25,25);
          xTaskNotify(task_FollowLineHandle,0,eSetValueWithOverwrite);
        }
      }
      break;
    default:
      break;
    }
  } 
}

void FollowLine_Boarder(void);
void FollowLine_Square(void);

uint32_t noteFlag[4]={0,0,0,0};

//巡线任务，当接收到按下key2的任务通知时从阻塞态转为就绪态
//会等待750ms，如果串口没有输入（K210没有检测到黑框）将寻边线，否则寻黑框
void Task_FollowLine(void const * argument){
  uint8_t squareFlag=0;
  while (1)
  {   
      //notification from key_2
      xTaskNotifyWait(0,0xffff,NULL,osWaitForever);

			printf("hello\n");

      /*串口接收一个坐标对应noteFlag[i]被置为1*/
      //重置
      for(int i=0;i<4;i++){
        noteFlag[i]=0;
      }
      //wait for uart signal from k210
      vTaskDelay(750);//

      //重新校验
      squareFlag=1;
      for(int i=0;i<4;i++){
        if(!noteFlag[i]) squareFlag=0;
      }

      //taskENTER_CRITICAL();
      if(squareFlag){
        //follow black line
        FollowLine_Square();
      }else{
        //follow boarder
        FollowLine_Boarder();
      }

      //taskEXIT_CRITICAL();
  }
}

#define STEP_TIME 60
#define STEP_LENTH 1
#define K210_X (50.0l/96.0l)
#define K210_y (50.0l/97.0l)
void FollowLine_Boarder(void){
  double cx=-1,cy=-1;

  while (cx<=48.5)
  {
    System_setToCoordinate(cx++,cy);
    vTaskDelay(STEP_TIME);
  }//cx==51
  while (cy<=50)
  {
    System_setToCoordinate(cx,cy++);
    vTaskDelay(STEP_TIME);
  }
  while(cx>=0.5){
    System_setToCoordinate(--cx,cy);
    vTaskDelay(STEP_TIME);
  }
  while (cy>=0)
  {
    System_setToCoordinate(cx,--cy);
    vTaskDelay(STEP_TIME);
  }  
}

double myAbs(double x){
    return x>0?x:-x;
}
//统一用double运算，只在接口处强转为int
//计算出两点的一次函数，然后巡线
void FollowLine_Square_OneLine(double x1,double y1,double x2,double y2){
  // x1+=1;x2+=1;
  // y1+=1;y2+=1;
  double x=x1,y=y1;

  if(myAbs(x1-x2)<=2.5*STEP_LENTH){//竖线
    double step=(y1>y2)?-STEP_LENTH:STEP_LENTH;
    double mid=(x1+x2)/2;
    while(myAbs(y-y2)>1.1*STEP_LENTH){//移动
      System_setToCoordinate(mid*K210_X,y*K210_y);
      y+=step;
      vTaskDelay(STEP_TIME);
    }
    System_setToCoordinate(mid*K210_X,y2*K210_y);
  }else{
    double k=(y2-y1)/(x2-x1),b=(x2*y1-x1*y2)/(x2-x1);
    double step=(x1>x2)?-STEP_LENTH:STEP_LENTH;

    while(myAbs(x-x2)>1.1*STEP_LENTH){
      printf("--x:%.4lf y:%.4lf--",x,y);
      System_setToCoordinate(x*K210_X,y*K210_y);
      x+=step;
      y=k*x+b;
      vTaskDelay(STEP_TIME);
    }
    System_setToCoordinate(x2*K210_X,y2*K210_y);
  }
}

extern int16_t squareCoordinates[4][2];

void FollowLine_Square(void){
  //get sqare coordinate

  double x1=squareCoordinates[0][0],y1=squareCoordinates[0][1],
          x2=squareCoordinates[1][0]-5.25,y2=squareCoordinates[1][1],
          x3=squareCoordinates[2][0]-5.25,y3=squareCoordinates[2][1],
          x4=squareCoordinates[3][0],y4=squareCoordinates[3][1];

  printf("enter follow square\n");
  // printf("x1:%d y1:%d\n",x1,y1);
  // printf("x2:%d y2:%d\n",x2,y2);
  // printf("x3:%d y3:%d\n",x3,y3);
  // printf("x4:%d y4:%d\n",x4,y4);

  
  //0->1
  System_setToCoordinate(x1-2,y1+2);
  vTaskDelay(10);

  FollowLine_Square_OneLine(x1-2,y1+1.4,x2,y2);

  FollowLine_Square_OneLine(x2,y2,x3,y3-1);

  FollowLine_Square_OneLine(x3,y3,x4,y4);
  printf("--line four--");
  FollowLine_Square_OneLine(x4,y4,x1,y1);
  
  System_setToCoordinate(x1,y1+2);
  
}
/* USER CODE END Application */

