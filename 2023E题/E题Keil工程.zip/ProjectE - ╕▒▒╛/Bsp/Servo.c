#include "Servo.h"
#include<stdio.h>


extern TIM_HandleTypeDef htim3;

int16_t upperAngle=0;
int16_t lowerAngle=0;

//云台朝向正中正前的基准值
//之后传入的值都应该加上基准值
const float verticalReference=362,  //越大越向下 18
            horizontalReference=1500;//越大越向左 500
/*
PSC 80
ARR 18000 450-2250有效
*/
void Servo_Init(void){
    HAL_TIM_PWM_Start(&htim3,UPPER_CHANNEL);
    HAL_TIM_PWM_Start(&htim3,LOWER_CHANNEL);

    __HAL_TIM_SET_COMPARE(&htim3,UPPER_CHANNEL,0);
    __HAL_TIM_SET_COMPARE(&htim3,LOWER_CHANNEL,0);
    
    upperAngle=120;
    lowerAngle=120;

    Servo_SetAngle(0,UPPER_CHANNEL);
    Servo_SetAngle(0,LOWER_CHANNEL);
}

void Servo_SetPWM(int16_t pwmVal,uint16_t channel){
    __HAL_TIM_SET_COMPARE(&htim3,channel,pwmVal+450);
}

void Servo_SetAngle(int16_t angle,uint32_t channel){
    if(channel==UPPER_CHANNEL){
        upperAngle=-angle+verticalReference;
        //printf("%d\n",upperAngle);
        Servo_SetPWM(upperAngle,channel);
    }
    else if(channel==LOWER_CHANNEL){
        //printf("lower :%d",angle);
        lowerAngle=-angle+horizontalReference;
        Servo_SetPWM(lowerAngle,channel);
    }
}

