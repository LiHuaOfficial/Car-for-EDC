#ifndef _SERVO_H_
#define _SERVO_H_

#include "stm32f1xx.h"

#define UPPER_CHANNEL TIM_CHANNEL_1
#define LOWER_CHANNEL TIM_CHANNEL_2

#define HORIZONTAL_CHANNEL LOWER_CHANNEL
#define VERTICAL_CHANNEL   UPPER_CHANNEL

/// @brief 初始化舵机，使激光笔对准底边线的正中
/// @param  
void Servo_Init(void);

/// @brief 设置舵机角度
/// @param angle 理论上传入值为-1800到1800 即-180-180度，但实际上传入值和servo.c基准值的和再加上450必须在这个范围内450-2250
/// @param channel 见servo.h头文件的宏定义
void Servo_SetAngle(int16_t angle,uint32_t channel);

#endif
